# RaftaarRide — Admin Panel

React + Vite + TailwindCSS admin dashboard for RaftaarRide platform.

## 📁 Folder Structure

```
RaftaarRide_Admin/
├── src/
│   ├── pages/          ← Dashboard, KYC, Drivers, Users, Rides, Withdrawals
│   ├── components/     ← Sidebar, shared UI components
│   ├── context/        ← Auth context
│   ├── hooks/          ← Real-time hooks
│   └── lib/            ← Socket.IO, utilities
├── lib/
│   └── api-client-react/  ← API client (included, no separate install needed)
├── public/             ← Logo and assets
├── vite.config.ts      ← Standalone config (no Replit plugins)
├── package.json
└── .env.example
```

## ⚡ Quick Setup

### 1. Install dependencies
```bash
npm install
# or
yarn install
```

### 2. Configure environment
```bash
cp .env.example .env
```
Edit `.env`:
```
VITE_API_URL=http://localhost:3000/api
```
> Replace with your deployed backend URL in production

### 3. Run locally
```bash
npm run dev
```
Admin panel will open at: **http://localhost:5173**

### 4. Build for production
```bash
npm run build
```
Output will be in `dist/` folder — deploy to any static hosting (Netlify, Vercel, Nginx)

---

## 🔐 Default Admin Login
- **Email:** `admin@raftaarride.com`
- **Password:** `Admin@123`

> Change this in backend `admin.ts` route before going live!

---

## 🖥️ Pages

| Page | URL | Description |
|------|-----|-------------|
| Login | `/login` | Admin authentication |
| Dashboard | `/` | Revenue stats + analytics charts |
| KYC | `/kyc` | Approve/reject driver documents |
| Drivers | `/drivers` | Manage all drivers |
| Users | `/users` | Manage all passengers |
| Rides | `/rides` | Complete ride history |
| Withdrawals | `/withdrawals` | Driver payout requests |

---

## ⚙️ Backend Required
This admin panel requires the **RaftaarRide API Server** running.

Backend repo is in the `backend/` folder of the full project download.

Backend port default: `3000`

---

## 🔌 Real-time Features
- Live KYC updates via Socket.IO
- Auto-refresh on new ride bookings
- Driver online/offline status

---

## 🛠️ Tech Stack
- React 19 + TypeScript
- Vite 6
- TailwindCSS 4
- Recharts (analytics charts)
- TanStack Query (data fetching)
- Socket.IO client (real-time)
- Radix UI + shadcn/ui components
- Wouter (routing)
